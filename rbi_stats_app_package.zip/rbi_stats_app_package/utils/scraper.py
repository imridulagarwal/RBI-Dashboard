import requests
from bs4 import BeautifulSoup
import re
from datetime import datetime
import logging
from src.models.db import db
from src.models.bank import Bank
from src.models.monthly_statistic import MonthlyStatistic

logger = logging.getLogger(__name__)

BASE_URL = "https://www.rbi.org.in/Scripts/ATMView.aspx"

def get_available_months():
    """
    Fetch the list of available months from the RBI website
    Returns a list of tuples (month_name, month_url, is_revised)
    """
    try:
        response = requests.get(BASE_URL)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        months = []
        
        # Find all month links
        for link in soup.find_all('a'):
            text = link.get_text()
            if "Bank-wise ATM/POS/Card Statistics" in text:
                href = link.get('href')
                if href:
                    # Extract month and year from text
                    match = re.search(r'(\w+)\s+(\d{4})', text)
                    if match:
                        month_name = match.group(1)
                        year = match.group(2)
                        is_revised = "(Revised)" in text
                        
                        # Create a tuple of (month_name, url, is_revised)
                        months.append((f"{month_name} {year}", href, is_revised))
        
        return months
    except Exception as e:
        logger.error(f"Error fetching available months: {str(e)}")
        return []

def parse_month_data(month_url):
    """
    Parse the data for a specific month
    Returns a list of dictionaries with bank data
    """
    try:
        full_url = f"https://www.rbi.org.in{month_url}" if not month_url.startswith('http') else month_url
        response = requests.get(full_url)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract month and year from page title or URL
        month_year_match = re.search(r'(\w+)\s+(\d{4})', soup.title.string if soup.title else '')
        if not month_year_match and month_url:
            month_year_match = re.search(r'atmid=(\d+)', month_url)
        
        if not month_year_match:
            logger.error(f"Could not extract month and year from {full_url}")
            return None, []
        
        # Convert month name to date object
        month_str = month_year_match.group(1) if month_year_match.group(1) else "January"
        year_str = month_year_match.group(2) if month_year_match.group(2) else "2025"
        month_date = datetime.strptime(f"01 {month_str} {year_str}", "%d %B %Y").date()
        
        # Find the main data table
        table = soup.find('table', {'cellspacing': '1', 'cellpadding': '1'})
        if not table:
            logger.error(f"Could not find data table in {full_url}")
            return month_date, []
        
        # Extract headers
        headers = []
        header_rows = table.find_all('tr')[:3]  # First three rows are headers
        
        # Process bank data rows
        bank_data = []
        bank_type = None
        
        for row in table.find_all('tr')[3:]:  # Skip header rows
            cells = row.find_all('td')
            
            # Check if this is a bank type header row
            if len(cells) == 1 or (len(cells) > 1 and not cells[0].get_text().strip().isdigit()):
                bank_type_text = cells[0].get_text().strip()
                if bank_type_text:
                    bank_type = bank_type_text
                continue
            
            # Skip rows with insufficient data
            if len(cells) < 12:
                continue
            
            try:
                # Extract bank data
                bank_data.append({
                    'bank_type': bank_type,
                    'bank_name': cells[1].get_text().strip(),
                    'atm_onsite': int(cells[2].get_text().strip() or 0),
                    'atm_offsite': int(cells[3].get_text().strip() or 0),
                    'pos_terminals': int(cells[4].get_text().strip() or 0),
                    'micro_atms': int(cells[5].get_text().strip() or 0),
                    'bharat_qr_codes': int(cells[6].get_text().strip() or 0),
                    'upi_qr_codes': int(cells[7].get_text().strip() or 0),
                    'credit_cards': int(cells[8].get_text().strip() or 0),
                    'debit_cards': int(cells[9].get_text().strip() or 0),
                    'pos_txn_volume': int(cells[10].get_text().strip().replace(',', '') or 0),
                    'pos_txn_value': float(cells[11].get_text().strip().replace(',', '') or 0),
                    'online_txn_volume': int(cells[12].get_text().strip().replace(',', '') or 0) if len(cells) > 12 else 0,
                    'online_txn_value': float(cells[13].get_text().strip().replace(',', '') or 0) if len(cells) > 13 else 0
                })
            except (ValueError, IndexError) as e:
                logger.warning(f"Error parsing row data: {str(e)}")
                continue
        
        return month_date, bank_data
    
    except Exception as e:
        logger.error(f"Error parsing month data: {str(e)}")
        return None, []

def update_database(month_date, bank_data, is_revised):
    """
    Update the database with the parsed data
    """
    try:
        # Process each bank
        for data in bank_data:
            # Find or create bank
            bank = Bank.query.filter_by(bank_name=data['bank_name']).first()
            if not bank:
                bank = Bank(
                    bank_name=data['bank_name'],
                    bank_type=data['bank_type']
                )
                db.session.add(bank)
                db.session.flush()  # Get the bank_id without committing
            
            # Find existing statistic for this bank and month
            stat = MonthlyStatistic.query.filter_by(
                bank_id=bank.bank_id,
                month=month_date
            ).first()
            
            # If statistic exists and is not revised, or if it's a new entry
            if not stat or (is_revised and not stat.is_revised):
                if stat:
                    # Update existing record if it's being revised
                    stat.is_revised = True
                    stat.atm_onsite = data['atm_onsite']
                    stat.atm_offsite = data['atm_offsite']
                    stat.pos_terminals = data['pos_terminals']
                    stat.micro_atms = data['micro_atms']
                    stat.bharat_qr_codes = data['bharat_qr_codes']
                    stat.upi_qr_codes = data['upi_qr_codes']
                    stat.credit_cards = data['credit_cards']
                    stat.debit_cards = data['debit_cards']
                    stat.pos_txn_volume = data['pos_txn_volume']
                    stat.pos_txn_value = data['pos_txn_value']
                    stat.online_txn_volume = data['online_txn_volume']
                    stat.online_txn_value = data['online_txn_value']
                else:
                    # Create new record
                    stat = MonthlyStatistic(
                        bank_id=bank.bank_id,
                        month=month_date,
                        is_revised=is_revised,
                        atm_onsite=data['atm_onsite'],
                        atm_offsite=data['atm_offsite'],
                        pos_terminals=data['pos_terminals'],
                        micro_atms=data['micro_atms'],
                        bharat_qr_codes=data['bharat_qr_codes'],
                        upi_qr_codes=data['upi_qr_codes'],
                        credit_cards=data['credit_cards'],
                        debit_cards=data['debit_cards'],
                        pos_txn_volume=data['pos_txn_volume'],
                        pos_txn_value=data['pos_txn_value'],
                        online_txn_volume=data['online_txn_volume'],
                        online_txn_value=data['online_txn_value']
                    )
                    db.session.add(stat)
        
        # Commit all changes
        db.session.commit()
        return True
    
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating database: {str(e)}")
        return False

def check_for_updates(app):
    """
    Check for new data and update the database
    This function is called by the scheduler
    """
    with app.app_context():
        try:
            logger.info("Checking for updates...")
            
            # Get available months
            months = get_available_months()
            if not months:
                logger.warning("No months found")
                return
            
            # Process each month
            for month_name, month_url, is_revised in months:
                logger.info(f"Processing {month_name} (Revised: {is_revised})")
                
                # Parse month data
                month_date, bank_data = parse_month_data(month_url)
                if not month_date or not bank_data:
                    logger.warning(f"No data found for {month_name}")
                    continue
                
                # Update database
                success = update_database(month_date, bank_data, is_revised)
                if success:
                    logger.info(f"Successfully updated data for {month_name}")
                else:
                    logger.error(f"Failed to update data for {month_name}")
            
            logger.info("Update check completed")
        
        except Exception as e:
            logger.error(f"Error in update process: {str(e)}")
